package com.example.geo_visit_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
